package GlobalVars;

/**
 * Created by gcdc on 6/7/17.
 */
public class GlobalVars {
    public static Long START_TIME;
    public static int FILE_SIZE; //Number of lines in a file
    public static boolean DEBUG;
}
